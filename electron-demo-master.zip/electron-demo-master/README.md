# Electron Demo
This is an application I created to showcase the electron framework!

There is also a video about this project:
https://www.youtube.com/watch?v=ZHeP0ugMoqo
